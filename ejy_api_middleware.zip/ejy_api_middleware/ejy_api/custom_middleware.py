from django.http import HttpResponseForbidden

class RoleBasedAccessMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        # Check if the user is authenticated
        if request.user.is_authenticated:
            # Check if the user is allowed to create, update, or delete blogs
            if not self.has_blog_permissions(request.user):
                return HttpResponseForbidden("You don't have permission to perform this action.")

        return response

    def has_blog_permissions(self, user):
        # Define the roles that have full control over blogs
        allowed_roles = ['Admin', 'Moderator', 'Content-Creator']

        # Check if the user's role is allowed
        user_role = user.roles
        return user_role in allowed_roles

    def has_blog_view_permission(self, user, blog):
        # Check if the user is the author of the blog
        if user == blog.user:
            return True

        # Check if the user has specific roles
        allowed_roles = ['Admin', 'Moderator', 'Content-Creator']
        return user.roles in allowed_roles
