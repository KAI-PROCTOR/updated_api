from django.contrib import admin
from .models import Customuser

admin.site.register(Customuser)
# Register your models here.
